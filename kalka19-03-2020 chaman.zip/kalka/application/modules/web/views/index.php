
	<?php include 'layout/css.php'; ?>
    <?php include 'layout/header.php'; ?>

    <?php echo $main_content; ?>

    <?php include 'layout/footer.php';?>