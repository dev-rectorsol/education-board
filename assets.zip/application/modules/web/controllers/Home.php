<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('article_model');
	}

	public function index(){
        $data = array();
        $data['homeSlider'] = 1;
        $data['main_content'] = $this->load->view('home', $data, true);
        $this->load->view('index', $data);
    }

		public function paths(){
			$data = array();
			$data['breadcrumbs'] = [array('url' => base_url('paths'), 'name' => 'Paths')];
			$data['main_content'] = $this->load->view('course-path', $data, true);
			$this->load->view('index', $data);
		}
		public function blogs(){
			$data = array();
			$data['breadcrumbs'] = [array('url' => base_url('blogs'), 'name' => 'Blogs')];
			$data['featured'] = $this->article_model->featured_article();
			$data['main_content'] = $this->load->view('blogs/blogs', $data, true);
			$this->load->view('index', $data);
		}

		public function blog_single_view($id){
			$data = array();
			$blog = $this->article_model->article_single_view($id);
			$data['breadcrumbs'] = [
				array('url' => base_url('blogs'), 'name' => 'Blogs'),
				array('url' => base_url('single') . '/' . $id, 'name' => $blog->title)
			];
			$data['user'] = $this->common_model->get_user_view_by_id($blog->user_id);
			$data['category'] = $this->common_model->get_category_name_by_blogid($blog->postid);
			$data['blog'] = $blog;
			$data['main_content'] = $this->load->view('blogs/blog-single', $data, true);
			$this->load->view('index', $data);
		}

    public function about(){
        $data = array();
        $data['page'] = 'About Us';
        $data['main_content'] = $this->load->view('about', $data, true);
        $this->load->view('index', $data);
    }

    public function courses(){
        $data = array();
        $data['page'] = 'Courses';
        $data['main_content'] = $this->load->view('courses', $data, true);
        $this->load->view('index', $data);
    }

    public function courseDetails(){
        $data = array();
        $data['page'] = 'course details';
        $data['main_content'] = $this->load->view('courseDetails', $data, true);
        $this->load->view('index', $data);
    }

    public function event(){
        $data = array();
        $data['page'] = 'Event';
        $data['main_content'] = $this->load->view('event', $data, true);
        $this->load->view('index', $data);
    }

    public function contact(){
        $data = array();
        $data['page'] = 'contact';
        $data['main_content'] = $this->load->view('contact', $data, true);
        $this->load->view('index', $data);
    }

    public function faq(){
        $data = array();
        $data['page'] = 'faq';
        $data['main_content'] = $this->load->view('faq', $data, true);
        $this->load->view('index', $data);
    }

}

/* End of file Home.php */
/* Location: ./application/modules/web/controllers/Home.php */ ?>
