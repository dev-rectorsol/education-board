# education-board
# Modules List
Admin	- Login Module
		- Api
		- Web Application
		- WebSite
	- Media
		- Uploads
		- View
		- Delete
	- Course
		- add
		- View
		-View grid
	-Aim
		-add
		-view
	-Category
		-add
		-view
	-Lesson
		-add
		-view
	-Subject
		-add
		-view
Register   -Register
	   -User




		 DB : mGov1YydXqG{


			 <!-- Rector SERVER -->
			 User: mcfojotc_education
			 Database: mcfojotc_education
			 DB: VV3Ha=QRq(gf
