<!-- Home Slider header -->

<header class="header <?php echo isset($homeSlider) ? 'header-transparent uk-light' : 'uk-sticky'; ?>" uk-sticky="top:20 ; cls-active:header-sticky; <?php echo isset($homeSlider) ? 'cls-inactive: uk-light' : ''; ?>">
