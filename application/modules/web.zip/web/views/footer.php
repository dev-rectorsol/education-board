<!-- footer
   ================================================== -->
<div class="footer">
  <div class="uk-grid-collapse" uk-grid>
    <div class="uk-width-expand@s uk-first-column">
      <p>© 2020 <strong>Kalka Ias Zone</strong>. All Rights Reserved. developed by <a href="http://rectorsol.com">Rector Sol</a> </p>
    </div>
    <div class="uk-width-auto@s">
      <nav class="footer-nav-icon">
        <ul>
          <li><a href="<?php echo base_url('about'); ?>">About us</a></li>
          <li><a href="<?php echo base_url('contact'); ?>">Contact us</a></li>
          <li><a href="<?php echo base_url('privacy'); ?>">Privacy Policy</a></li>
          <li><a href="https://www.facebook.com/kalkaiasacademy/"><i class="icon-brand-facebook"></i></a></li>
          <li><a href="https://www.youtube.com/channel/UCar0_5Q8f-IPCLZ-2c2VyGQ"><i class="icon-brand-youtube"></i></a></li>
        </ul>
      </nav>
    </div>
  </div>
</div>
