<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Login extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
       
        $this->load->helper('date');
         $this->load->model('Common_model');
        $this->load->helper('url');

    }


    public function index_post()
    {
        // $this->some_model->update_user( ... );
        $message = [
           
            'email' => $this->post('email'),
            'password' => $this->post('password'),
             'role' => $this->post('role'),
        ];
        
        if(empty($message['email']) || empty($message['password']) ){
     
            $this->response(['status' => False,
                    'message' =>'Invalid Parameters'], REST_Controller::HTTP_BAD_REQUEST);  
        }
        $str = $this->Common_model->Login_check($message);
   
        if($str) 
       
            {
                $data['status'] =true;
                $data['message'] = 'User Found';
                $data['data'] =$str;
                $data1=[
                    'user_id'=> $str[0]['logid'],
                    'ip' => $_SERVER['REMOTE_ADDR'],
                    'lastlog' => date('Y-m-d:h-m-s')
                ];
                 $this->Common_model->insert($data1,'log');
                $this->response($data, REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code
            }
         else{
              $this->response(['status' => False,
                    'message' =>'User Not Found'], REST_Controller::HTTP_BAD_REQUEST);
         }
     
       
    }
  public function mobile_post()
    {
        
        $message = [
           
            'mobile' => $this->post('mobile'),
         
        ];
        
        $str = $this->Common_model->Login_check_mobile($message);
    
        if($str==false) 
       
            {
                $this->response(['status' => False,
                    'message' =>'User Not Found'], REST_Controller::HTTP_BAD_REQUEST);
               
            }
         else{
              $data['status'] =true;
                $data['message'] = 'User Found';
                $data['data'] =$str;
                $data1=[
                    'id'=> $str[0]['logid'],
                    'ip' => $this->post('ip'),
                    'lastlog' => date('Y-m-d:h-m-s')
                ];
                
                 $this->Common_model->insert($data1,'log');
                
                
                $this->response($data, REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code 
         }
     
       
    }
   

}
