<?php
  echo "<pre>";
  echo var_dump($upload);
?>
