<script type="text/javascript">
  // lightGallery(document.getElementById('lightgallery'));

</script>
